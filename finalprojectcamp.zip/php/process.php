<?php
session_start();
require_once "database.php"; // adjust path if needed

$quantity = $_POST['quantity'] ?? 0;

if ($quantity <= 0) {
    echo "<script>alert('You must select at least one item!'); window.history.back();</script>";
    exit;
}

// Handle form submission with security code
if (isset($_POST['security'])) {
    $enteredCode = trim($_POST['security']);

    // Check if the code exists in the users table
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE security_code = ?");
    mysqli_stmt_bind_param($stmt, "s", $enteredCode);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) === 0) {
        echo "<script>alert('Invalid security code.'); window.history.back();</script>";
        exit;
    }

    // You could also fetch the user record here if needed
}
?>

<!-- Show security code form (if not already submitted) -->
<?php if (!isset($_POST['security'])): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enter Security Code</title>
</head>
<body>

    <h2>You selected <?= htmlspecialchars($quantity) ?> item(s)</h2>

    <form action="process.php" method="post">
        <input type="hidden" name="quantity" value="<?= htmlspecialchars($quantity) ?>">
        <label for="security">Enter Security Code:</label>
        <input type="text" id="security" name="security" required>
        <br><br>
        <input class="confirmrental" type="submit" value="Confirm Rental">
    </form>

</body>
</html>

<style>
    body {
        text-align: center;
        background: #606c38;
    }

    form {
        background-color: #dda15e;
        margin: auto;
        text-align: center;
        padding-top: 10px;
        width: 300px;
        height: 200px;
        border-radius: 5px;
    }

    .confirmrental {
        background-color: #bc6c25;
        border: none;
        font-size: 20px;
        font-weight: bold;
        font-family: 'Lucida Sans', sans-serif;
        border-radius: 12px;
        padding: 15px;
        margin: 20px auto;
        box-shadow: 2px 2px 8px rgba(0,0,0,0.1);
    }

    .confirmrental:hover {
        background-color: rgb(47, 26, 8);
        box-shadow: 0 0 10px #151f16;
    }
</style>
<?php else: ?>

<!-- If security code is valid, redirect to finalize.php -->
<form id="redirectForm" action="finalize.php" method="post">
    <input type="hidden" name="quantity" value="<?= htmlspecialchars($quantity) ?>">
    <input type="hidden" name="security" value="<?= htmlspecialchars($_POST['security']) ?>">
</form>
<script>
    document.getElementById('redirectForm').submit();
</script>

<?php endif; ?>
