<?php
session_start();
?>
<?php
// Get form data safely
$quantity = $_POST['quantity'] ?? 0;
$securityCode = $_POST['security'] ?? '';

if ($quantity <= 0 || empty($securityCode)) {
    echo "<script>alert('Missing quantity or security code.'); window.history.back();</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 3em;
            background: #606c38;
        }
        .confirmation {
            padding: 2em;
            border: 2px solid #dda15e;
            background-color: #dda15e;
            display: inline-block;
        }
        h2 {
            color:rgb(0, 0, 0);
        }

        button {
    background-color: #bc6c25;
    border: #bc6c25;
    font-size: 20px;
    font-weight: bold;
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      border-radius: 12px;
            padding: 15px;
            margin: 20px auto;
            box-shadow: 2px 2px 8px rgba(0,0,0,0.1); 
}



button:hover{
            background-color:rgb(47, 26, 8);
            box-shadow: 0 0 10px #151f16;
        }

        
    </style>
</head>
<body>
    <div class="confirmation">
        <h2>Please confirm your order</h2>
        <p>The following has been purchased under <?= htmlspecialchars($_SESSION["user"]["first_name"] ?? 'your account') ?></p>

        <p><strong>Quantity:</strong> <?= htmlspecialchars($quantity) ?></p>
        <p><strong>Security:</strong> <?= htmlspecialchars($securityCode) ?></p>
        <p>If you do not wish to proceed with the order, please click the back button.</p>
        <button><a class="confirmcss"  href="equip.html">Click here</a></button>
    </div>
</body>
</html>
