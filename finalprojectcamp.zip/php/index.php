<!DOCTYPE html>
<!-- Temar Davis Equipment Page -->
<html lang="en">
<head>
    <title>Haley Campgrounds</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        form {
            max-width: 600px;
            margin: 30px auto;
            padding: 25px;
            background-color: #ffffffcc;
            border-radius: 12px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
            font-family: 'Lucida Sans', sans-serif;
        }

        form label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        form input, form select, form textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        form button {
            background-color: #3e8e41;
            color: white;
            padding: 12px 25px;
            margin-top: 20px;
            font-size: 18px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #2e6f31;
        }

        header img.banner-img {
            width: 100%;
        }

        nav, footer {
            text-align: center;
            padding: 15px;
        }

        body {
            background-color: #606c38;
        }

        .whitetext {
            text-align: center;
            color: white;
            font-size: 20px;
            margin-top: 20px;
        }

        ul {
            list-style: none;
            text-align: center;
            background-color: #283618;
            padding: 10px 0;
            margin: 0;
        }

        ul li {
            display: inline;
            margin: 0 15px;
        }

        ul li a {
            color: #f6eee4;
            text-decoration: none;
            font-size: 18px;
        }

        ul li a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function setFilter(type, value) {
            console.log("Filter by", type, value);
            // Implement filter logic here
        }
    </script>
</head>
<body>
<?php
session_start();
require_once "database.php";
?>
    <header>
        <img src="images/Campgrounds.png" alt="haleylogo" class="banner-img">
        <div class="user-greeting">
            <?php
            if (isset($_SESSION["user"])) {
                echo "Welcome, " . htmlspecialchars($_SESSION["user"]["first_name"]);
            }
            ?>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="activity.html">Activity</a></li>
            <li><a href="equip.html">Equipment</a></li>
            <li><a href="cafes.html">Cafes</a></li>
            <li><a href="wildlife.html">Wildlife</a></li>
             <li><a href="registration.html">Registration</a></li>
            <?php if (!isset($_SESSION["user"])): ?>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Login</a></li>
            <?php else: ?>
                <li><a href="logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <div class="centering">
        <!-- Dropdown filters -->
        <!-- (unchanged markup, just added JS function) -->
    </div>

    <main>
        <div class="welcometext">
            <h1>Welcome to Haley Campgrounds</h1> 
        </div>
        <div class="fifteen">
            <h2>For over 15 years</h2>
        </div>
        <div class="homepage">
            <p>Haley Campgrounds has been providing accessible camping resources in Georgia! ...</p>
        </div>
        <div class="imagehome">
            <img src="images/photo-1504280390367-361c6d9f38f4.jpg" width="450">
        </div>
        <div class="navigation">
            <h1>Navigation Panel</h1>
        </div>
        <div class="grid-container">
            <img src="images/istockphoto-186835742-612x612.jpg" width="150">
        </div>
    </main>

    <footer>
        <p><a href="index.php">Home</a> <a href="activity.html">Activity</a> &nbsp;  <a href="equip.html">Equipment</a> &nbsp;  <a href="cafes.html">Cafes</a> &nbsp;  <a href="wildlife.html">Wildlife</a> &nbsp; <a href="registration.html">Registration</a>  </p>
        <p>770-371-7202</p>
        <p>haleycampground@gmail.com</p>
        <p>&copy; Copyright 2025. All Rights Reserved.</p>
    </footer>
</body>
</html>