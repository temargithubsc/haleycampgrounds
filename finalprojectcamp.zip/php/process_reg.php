<?php
// Basic validation and sanitation
$fullname = htmlspecialchars($_POST['fullname'] ?? '');
$email = htmlspecialchars($_POST['email'] ?? '');
$campsite = htmlspecialchars($_POST['campsite'] ?? '');
$guests = (int)($_POST['guests'] ?? 0);
$requests = htmlspecialchars($_POST['requests'] ?? '');

// Check required fields
if (empty($fullname) || empty($email) || empty($campsite) || $guests < 1) {
    echo "<script>alert('Please fill out all required fields.'); window.history.back();</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Confirmed | Haley Campgrounds</title>
    <link rel="stylesheet" href="css/regstyles.css">
    <style>
        body {
            background-color: #606c38;
            font-family: 'Lucida Sans', sans-serif;
            color: #1b1b1b;
        }

        .confirmation-box {
            background-color: #ffffffcc;
            border-radius: 12px;
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            box-shadow: 2px 2px 8px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: #283618;
        }

        p {
            margin-bottom: 15px;
        }

        footer {
            text-align: center;
            font-size: 0.85em;
            background-color: #283618;
            color: #f6eee4;
            padding: 1% 0;
            margin-top: 40px;
        }

        a.back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #3e8e41;
            font-weight: bold;
        }

        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="confirmation-box">
        <h2>Thank you for registering!</h2>
        <p><strong>Name:</strong> <?= $fullname ?></p>
        <p><strong>Email:</strong> <?= $email ?></p>
        <p><strong>Campsite:</strong> <?= $campsite ?></p>
        <p><strong>Number of Guests:</strong> <?= $guests ?></p>
        <?php if (!empty($requests)): ?>
            <p><strong>Special Requests:</strong> <?= $requests ?></p>
        <?php endif; ?>
        <p>We’ve received your request and will contact you soon with more details.</p>
        <a href="registration.html" class="back-link">← Back to Registration</a>
    </div>

    <footer>
        <p>Home &nbsp; | &nbsp; Activity &nbsp; | &nbsp; Equipment &nbsp; | &nbsp; Cafes &nbsp; | &nbsp; Wildlife</p>
        <p>770-371-7202 | haleycampground@gmail.com</p>
        <p>&copy; 2025 Haley Campgrounds. All Rights Reserved.</p>
    </footer>

</body>
</html>
