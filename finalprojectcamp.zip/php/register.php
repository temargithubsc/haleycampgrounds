<!-- register.php -->
<?php
session_start();
require_once "database.php";

if (isset($_POST["submit"])) {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    $errors = array();

    if (empty($firstname) || empty($lastname) || empty($phone_number) || empty($email) || empty($password)) {
        array_push($errors, "Please make sure all columns are filled out.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Invalid email entered");
    }

    if (strlen($password) < 8) {
        array_push($errors, "Password must be at least 8 characters");
    }

    if (!preg_match("/[a-z]/i", $password)) {
        array_push($errors, "Password must contain at least one letter");
    }

    if (!preg_match("/[0-9]/", $password)) {
        array_push($errors, "Password must contain at least one number");
    }

    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($result) > 0) {
        array_push($errors, "Email already exists");
    }

    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // ✅ Generate random security code (6 uppercase letters/numbers)
        $securityCode = strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));

        // ✅ Insert user with security_code
        $sql = "INSERT INTO users (first_name, last_name, phone_number, email, password, security_code) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($conn);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, "ssssss", $firstname, $lastname, $phone_number, $email, $passwordHash, $securityCode);
            mysqli_stmt_execute($stmt);

            // Optional: store user info in session
            $_SESSION['user'] = [
                "first_name" => $firstname,
                "email" => $email,
                "security_code" => $securityCode
            ];

            echo "<div class='alert alert-success'>You are now registered. Your security code is: <strong>$securityCode</strong></div>";
            header("Location: login.php");
            exit();
        } else {
            die("Something went wrong while preparing the statement.");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Signup</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="/js/validation.js" defer></script>
    <style>
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border: 1px solid #f5c6cb;
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <h1>Signup</h1>
    <section>
        <form action="register.php" method="post" id="signup">
            <fieldset>
                <label for="firstname">First name<br><input type="text" id="firstname" name="firstname"></label><br><br>
                <label for="lastname">Last name<br><input type="text" id="lastname" name="lastname"></label><br><br>
                <label for="phone">Phone #<br><input type="tel" id="phone" name="phone_number"></label><br><br>
                <label for="email">Email<br><input type="email" id="email" name="email"></label><br><br>
                <label for="password">Password<br><input type="password" id="password" name="password"></label><br><br>
                <input type="submit" name="submit" value="Sign Up">
            </fieldset>
        </form>
    </section>
</body>
</html>